import numpy as np
import scipy.io.wavfile as wavfile
from scipy.signal import butter, lfilter

#karol Cieslik

# Funkcja do utworzenia filtra Butterwortha
def butter_highpass(cutoff, fs, order=5):
    nyq = 0.5 * fs
    normal_cutoff = cutoff / nyq
    b, a = butter(order, normal_cutoff, btype='high', analog=False)
    return b, a

# Funkcja do zastosowania filtra do sygnału
def highpass_filter(data, cutoff, fs, order=5):
    b, a = butter_highpass(cutoff, fs, order=order)
    y = lfilter(b, a, data)
    return y

# Wczytanie pliku WAV
input_filename = '225.wav'
fs, data = wavfile.read(input_filename)

# Założenie, że dane są stereo, weźmy tylko lewy kanał
left_channel = data[:, 0]

# Filtracja sygnału
cutoff_frequency = 100.0  # 100 Hz
filtered_left_channel = highpass_filter(left_channel, cutoff_frequency, fs)

# Zapisanie przefiltrowanego pliku WAV (tylko lewy kanał)
output_filename = 'IDstudentaCwiczeniaDzwiękowe.wav'
filtered_data = np.column_stack((filtered_left_channel, data[:, 1]))  # Dodanie prawego kanału bez zmian
wavfile.write(output_filename, fs, filtered_data.astype(np.int16))

import numpy as np
import matplotlib.pyplot as plt
from scipy.io import wavfile

# Wczytanie przefiltrowanego pliku
filename = 'IDstudentaCwiczeniaDzwiękowe.wav'
fs, y = wavfile.read(filename)

# Jeśli dźwięk jest stereo, weź pierwszy kanał (lewy)
if len(y.shape) > 1:
    y = y[:, 0]

# Obliczenie FFT
n = len(y)
y_fft = np.fft.fft(y)
y_fft = np.abs(y_fft)  # Moduł wartości FFT
f = np.fft.fftfreq(n, 1/fs)

# Wykres widma
plt.figure()
plt.plot(f[:n//2], y_fft[:n//2])  # Wyświetlamy tylko dodatnie częstotliwości
plt.title('Widmo częstotliwościowe przefiltrowanego sygnału')
plt.xlabel('Częstotliwość (Hz)')
plt.ylabel('Amplituda')
plt.show()
